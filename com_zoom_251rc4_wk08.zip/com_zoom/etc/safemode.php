<?php
defined( '_VALID_MOS' ) or die( 'Direct Access to this location is not allowed.' );
$ftp_server = "";
$ftp_username = "";
$ftp_pass = "";
$ftp_hostdir = "";
?>